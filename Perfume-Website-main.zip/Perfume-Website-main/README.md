# Perfume-Website

All Images are Linked and the links which are used are linked below.

Links used to support CSS are :

1. Bootstrap :

https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css

2. Font Awesome :

https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css

3. Animate :

https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css

4. Owl Carousel :

https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.2.1/assets/owl.carousel.min.css

5. Nice Select :

https://cdnjs.cloudflare.com/ajax/libs/jquery-nice-select/1.1.0/css/nice-select.min.css


Links for javascript are :

1. jQuery js :

https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js

2. Popper js :

https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js

3. Bootstrap js :

https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js

4. Owl Carousel js :

https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.2.1/owl.carousel.min.js

5. Countdown js :

For this js i have uploaded a file. You can download from there.
countdown.js

6. Nice Select js: 

https://cdnjs.cloudflare.com/ajax/libs/jquery-nice-select/1.1.0/js/jquery.nice-select.min.js
